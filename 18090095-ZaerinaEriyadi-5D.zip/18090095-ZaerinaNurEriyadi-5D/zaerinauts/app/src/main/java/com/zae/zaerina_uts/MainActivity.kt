package com.zae.zaerina_uts

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.zae.zaerina_uts.helper.Constant
import com.zae.zaerina_uts.helper.PrefHelper
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    lateinit var prefHelper: PrefHelper
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefHelper = PrefHelper(this)

        textUsername.text = prefHelper.getString( Constant.PREF_USERNAME )

        button4.setOnClickListener {
            prefHelper.clear()
            showMessage( "Keluar" )
            moveIntent()
        }

        button.setOnClickListener {
            startActivity(Intent(this,KalkulatorActivity::class.java))
        }
        button2.setOnClickListener {
            startActivity(Intent(this,ProfileActivity::class.java))
        }
        button3.setOnClickListener {
            startActivity(Intent(this,BeritaActivity::class.java))
        }
    }
    private fun moveIntent(){
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }

    private fun showMessage(message: String) {
        Toast.makeText(applicationContext, message, Toast.LENGTH_SHORT).show()
    }
}