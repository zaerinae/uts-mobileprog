package com.zae.zaerina_uts

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.zae.zaerina_uts.adapter.ImageAdapter

class BeritaActivity : AppCompatActivity() {
    companion object{
        val INTENT_PARCELABLE = "OBJECT_INTENT"
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_berita)
        val imageList = listOf(
            Image(
                R.drawable.img1,
                "Ruang Guru",
                    " Ruangguru berhasil masuk daftar perusahaan teknologi di bidang pendidikan (edtech) paling transformatif di dunia versi GSV Ventures.\n" +
                            "\n" +
                            "Ruangguru merupakan satu-satunya perusahaan asal Indonesia dan Asia Tenggara yang masuk di dalam daftar tersebut.\n" +
                            "\n" +
                            "Selain Ruangguru, perusahaan lain kebanyakan berasal dari Amerika Serikat, Tiongkok, dan India. Ada 17 perusahaan asal Amerika Serikat, 16 perusahaan asal Tiongkok, dan 6 perusahaan asal India yang ada di dalam daftar ini."
            ),
            Image(
                R.drawable.img2,
                "Presiden SMU",
                    " Pandemi Virus Corona COVID-19 membuat dunia harus beradaptasi. Hal ini termasuk dalam dunia pendidikan, di mana kegiatan belajar mengajar tidak bisa lagi dilakukan dengan cara tradisional yaitu tatap muka dan harus beralih secara online. \n" +
                            "\n" +
                            "Hal ini tentu bukan merupakan suatu hal yang mudah, baik dari sisi pengajar maupun siswa. Kendala juga tak hanya dialami oleh siswa sekolah namun juga siswa perguruan tinggi. \n" +
                            "\n"
            ),
            Image(
                R.drawable.img3,
                "Pelajaran Sekolah di Qatar",
                    "Lembaga internasional mengungkap kurikulum pendidikan di Qatarbersifat intoleran kepada minoritas beragama. Temuan itu berdasarkan review di 238 buku pelajaran Qatar.\n" +
                            "\n" +
                            "Menurut Institute for Monitoring Peace and Cultural Tolerance in School Education (IMPACT-se), buku-buku pelajaran Qatar memberikan pandangan negatif kepada agama Kristen dan Yahudi."
            ),
            Image(
                R.drawable.img4,
                "Model Pendidikan Partisipatif",
                    "Jaringan Pendidikan Alternatif, sebuah organisasi cair berisi para individu, komunitas, dan penyelenggara pendidikan alternatif, menyatakan pemerintah dan masyarakat harus terus mendorong model pendidikan partisipatif dan memerdekakan anak.\n" +
                            "\n" +
                            "Program Organisasi Penggerak (POP) dan Program Guru Penggerak (PGP) yang digagas Kementerian Pendidikan dan Kebudayaan (Kemdikbud) dinilai menjadi bagian dari inisiasi untuk menciptakan pendidikan yang selaras dan sesuai kebutuhan lingkungan dengan banyak ragam model yang ditawarkan kepada anak.\n" +
                            "\n" +
                            "Koordinator Jaringan Pendidikan Alternatif Susilo Adinegoro menilai, apa pun terobosan untuk melibatkan masyarakat dalam pendidikan patut diapresiasi. Pendiri Sanggar Anak Akar yang fokus mendidik anak jalanan dan korban gusuran ini menilai, setidaknya terdapat tiga tujuan POP dan PGP sehingga masyarakat perlu memberi dukungan."
            ),
        )

        val recyclerView = findViewById<RecyclerView>(R.id._imageRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.setHasFixedSize(true)
        recyclerView.adapter = ImageAdapter(this, imageList){
            val intent = Intent(this, DetailActivity::class.java)
            intent.putExtra(INTENT_PARCELABLE, it)
            startActivity(intent)
        }

    }
}